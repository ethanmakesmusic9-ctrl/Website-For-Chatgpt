const defaultData = {
  countdown: {
    title: "HALLOWEEN UPDATE",
    name: "Halloween Update + New Cards",
    description: "The next big Open Cards For Brainrots update is coming!",
    target: new Date(Date.now() + 1000 * 60 * 60 * 24 * 3).toISOString()
  },
  units: [
    {icon:"🐐", rarity:"LEGENDARY", name:"Galaxy Goat", description:"A cosmic card with insane energy.", income:"$992M/s"},
    {icon:"🏠", rarity:"SECRET", name:"Lucky 9 House", description:"This little house might be hiding something.", income:"???/s"},
    {icon:"🥔", rarity:"MYTHIC", name:"Power Sahur", description:"An explosive Power Sahur card.", income:"$992M/s"},
    {icon:"👑", rarity:"SECRET", name:"Golden Brainrot", description:"A super rare pull for serious collectors.", income:"???/s"}
  ],
  updates: [
    {date:"LATEST", title:"Welcome to Open Cards!", text:"The official website is now live. Check back here for countdowns, unit drops, events, and more."},
    {date:"COMING SOON", title:"New Units", text:"More crazy Brainrot cards are being added soon. Keep opening!"},
    {date:"SOON", title:"Secret Drops", text:"Keep an eye out for limited-time secret cards and special events."}
  ]
};

function loadData(){
  try{
    const saved = JSON.parse(localStorage.getItem("ocfb_data"));
    return saved ? {...defaultData,...saved} : defaultData;
  }catch(e){ return defaultData; }
}
const data = loadData();

function renderUnits(){
  const grid = document.getElementById("unitGrid");
  grid.innerHTML = data.units.map(u => `
    <article class="unit-card">
      <div class="unit-icon">${escapeHtml(u.icon || "🃏")}</div>
      <div class="rarity">${escapeHtml(u.rarity || "NEW")}</div>
      <h3>${escapeHtml(u.name)}</h3>
      <p>${escapeHtml(u.description || "")}</p>
      <span class="unit-income">${escapeHtml(u.income || "")}</span>
    </article>
  `).join("");
}
function renderUpdates(){
  const list = document.getElementById("updatesList");
  list.innerHTML = data.updates.map(u => `
    <article class="update">
      <div class="update-date">${escapeHtml(u.date || "UPDATE")}</div>
      <h3>${escapeHtml(u.title)}</h3>
      <p>${escapeHtml(u.text || "")}</p>
    </article>
  `).join("");
}
function renderCountdown(){
  document.getElementById("countdownTitle").textContent = data.countdown.title || "NEXT EVENT";
  document.getElementById("countdownName").textContent = data.countdown.name || "Next Event";
  document.getElementById("countdownDescription").textContent = data.countdown.description || "";
}
function tick(){
  const target = new Date(data.countdown.target).getTime();
  let diff = Math.max(0, target - Date.now());
  const d = Math.floor(diff/86400000); diff %= 86400000;
  const h = Math.floor(diff/3600000); diff %= 3600000;
  const m = Math.floor(diff/60000); diff %= 60000;
  const s = Math.floor(diff/1000);
  const values=[d,h,m,s].map(n=>String(n).padStart(2,"0"));
  document.querySelectorAll("#timer b").forEach((el,i)=>el.textContent=values[i]);
  if(target <= Date.now()){
    document.getElementById("countdownName").textContent="EVENT IS LIVE! 🎉";
    document.getElementById("countdownDescription").textContent="Go play now on Roblox!";
  }
}
function escapeHtml(value){
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}
renderCountdown(); renderUnits(); renderUpdates(); tick(); setInterval(tick,1000);
