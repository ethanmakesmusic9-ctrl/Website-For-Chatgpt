# Open Cards For Brainrots — Website

## Included
- `index.html` — public website
- `admin.html` — creator/admin panel
- `styles.css` — fun dark/purple/pink styling
- `app.js` — countdown + unit/update rendering
- `assets/brainrot-cards.png` — uploaded card image
- `assets/brainrotcards3.png` — uploaded gameplay image

## Roblox button
The PLAY NOW buttons already point to:
https://www.roblox.com/games/107144354105957/Open-Cards-For-Brainrots

## Admin panel
Open `/admin.html`.
The demo PIN is `1234`. Change `ADMIN_PIN` inside `admin.html` before publishing.

IMPORTANT: This is a browser/localStorage starter panel. It is not secure authentication and changes are saved only in the browser/device. For a real private panel that works across devices, use a server/database with real authentication.

## Custom domain
The package is ready to deploy to a static host. After deployment, connect the domain `opencardsforbrainrots.com` (and usually `www`) in the hosting provider's domain/DNS settings.

You must own/register the domain and configure DNS with your registrar/hosting provider; the HTML package itself cannot register the domain.
